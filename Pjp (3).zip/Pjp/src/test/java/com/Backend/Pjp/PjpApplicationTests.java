package com.Backend.Pjp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjpApplicationTests {

	@Test
	void contextLoads() {
	}

}
