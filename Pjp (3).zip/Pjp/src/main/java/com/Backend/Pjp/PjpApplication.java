package com.Backend.Pjp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjpApplication {

	public static void main(String[] args) {
		SpringApplication.run(PjpApplication.class, args);
	}

}
